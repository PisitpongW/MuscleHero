Sounds from Harvest Moon: A Wonderful Life Special Edition
Ripped directly from PS2 iso using PSound by MamonFighter761
No credit required if use.